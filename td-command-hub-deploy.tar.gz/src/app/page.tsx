import GlassmorphismCapture from '@/components/landing/GlassmorphismCapture'

export default function HomePage() {
  return <GlassmorphismCapture />
}